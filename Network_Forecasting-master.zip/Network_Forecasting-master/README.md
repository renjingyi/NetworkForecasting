# Network Forecasting

## Project Target


## Project Progresses

1. download data
2. making models
3. design and implement the auto best parameters finding algorithm

## Resources
* [OTexts](https://www.otexts.org/fpp)
* [Holt's linear trend method](https://www.otexts.org/fpp/7/2)
* [A comprehensive beginner’s guide to create a Time Series Forecast (with Codes in Python)](https://www.analyticsvidhya.com/blog/2016/02/time-series-forecasting-codes-python/)
